# Value Kernel v1.0.0

The Value Kernel defines the immutable constitutional constraints governing intelligent systems in the Sovereign / TYME / AVOT ecosystem.

This repository is the root of ethical authority.

Constraint is what allows intelligence to endure.
