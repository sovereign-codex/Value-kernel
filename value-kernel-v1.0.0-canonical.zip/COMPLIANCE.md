# Value Kernel Compliance

Compliance is binary. Partial compliance claims are invalid.
