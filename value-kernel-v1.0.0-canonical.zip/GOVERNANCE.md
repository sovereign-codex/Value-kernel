# Value Kernel Governance

Version 1.0.0 is frozen. No in-place edits are permitted.
All changes require a new major version.
