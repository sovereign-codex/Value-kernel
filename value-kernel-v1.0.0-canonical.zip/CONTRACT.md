# Value Kernel Contract

All systems interacting with this kernel must fail closed, honor denial states, and escalate uncertainty.
