# Manifest

This manifest lists all canonical artifacts included in Value Kernel v1.0.0.
