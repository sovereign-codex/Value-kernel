# Value Kernel

The Value Kernel defines non-negotiable invariants that all downstream systems must obey.
These constraints are immutable for the lifetime of this version.
