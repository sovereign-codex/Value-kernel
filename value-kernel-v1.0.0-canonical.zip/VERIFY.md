# Verify

Verify integrity by checking hashes against published sums.
