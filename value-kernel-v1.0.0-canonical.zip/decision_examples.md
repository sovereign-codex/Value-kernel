# Decision Examples

This document illustrates how kernel decisions manifest in practice.
